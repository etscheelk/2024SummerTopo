

# - could write a function to show size of each vertex's connected component at each point in time

# a widget that lets you pick a vertex and slide a slider to show the connected component at each point in time

# a widget that lets you pick a cycle and slide a slider to show how the cycle fills in

