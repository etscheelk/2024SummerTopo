

# absolute versus relative python imports

https://realpython.com/absolute-vs-relative-python-imports/

# modifying externally defined objects 

for hints on extending externally defined objects with new methods, see https://stackoverflow.com/questions/9865455/adding-functions-from-other-files-to-a-python-class

# indexing dataframes

pandas does not support indexing dataframes with lists