#   THIS FILE IS INSPIRED BY THE BLOG POST
#   https://mgarod.medium.com/dynamically-add-a-method-to-a-class-in-python-c49204b85bd6
#
#   AND SPECIFICALLY THE FOLLOWING CODE EXERPT
#   
#   !!!!!!!!!!!!!!!!
#   HOWEVER
#
#   IT DOESN'T SEEM TO WORK AS AWELL AS THE METHOD ALREADY EMPLOYED IN filtered_clique.py,
#   IN PARTICULAR I COULDN'T GET THE NEW METHOD TO TAKE `self` AS AN ARGUMENT


# =========== EXCERPT: BEGIN ===============
# from functools import wraps # This convenience func preserves name and docstring

# class A:
#     pass

# def add_method(cls):
#     def decorator(func):
#         @wraps(func) 
#         def wrapper(self, *args, **kwargs): 
#             return func(*args, **kwargs)
#         setattr(cls, func.__name__, wrapper)
#         # Note we are not binding func, but wrapper which accepts self but does exactly the same as func
#         return func # returning func means func can still be used normally
#     return decorator

# # No trickery. Class A has no methods nor variables.
# a = A()
# try:
#     a.foo()
# except AttributeError as ae:
#     print(f'Exception caught: {ae}') # 'A' object has no attribute 'foo'

# try:
#     a.bar('The quick brown fox jumped over the lazy dog.')
# except AttributeError as ae:
#     print(f'Exception caught: {ae}') # 'A' object has no attribute 'bar'

# # Non-decorator way (note the function must accept self)
# # def foo(self):
# #     print('hello world!')
# # setattr(A, 'foo', foo)

# # def bar(self, s):
# #     print(f'Message: {s}')
# # setattr(A, 'bar', bar)

# # Decorator can be written to take normal functions and make them methods
# @add_method(A)
# def foo():
#     print('hello world!')

# @add_method(A)
# def bar(s):
#     print(f'Message: {s}')

# a.foo()
# a.bar('The quick brown fox jumped over the lazy dog.')
# print(a.foo) # <bound method foo of <__main__.A object at {ADDRESS}>>
# print(a.bar) # <bound method bar of <__main__.A object at {ADDRESS}>>

# # foo and bar are still usable as functions
# foo()
# bar('The quick brown fox jumped over the lazy dog.')
# print(foo) # <function foo at {ADDRESS}>
# print(bar) # <function bar at {ADDRESS}>
# =========== EXCERPT: END ===============


from functools import wraps # This convenience func preserves name and docstring
import pandas as pd
import oatpy
from fractions import Fraction


def add_method(cls):
    """
    Adds a method to a class
    """
    def decorator(func):
        @wraps(func) 
        def wrapper(self, *args, **kwargs): 
            return func(*args, **kwargs)
        setattr(cls, func.__name__, wrapper)
        # Note we are not binding func, but wrapper which accepts self but does exactly the same as func
        return func # returning func means func can still be used normally
    return decorator



# @add_method( oatpy.BarcodePySimplexFilteredRational )
# def to_dataframe(self):
#     """
#     Export the a barcode to a dataframe
#     """
#     id=[]; dim=[]; birth=[]; death=[]; birth_column=[]; death_column=[];
#     cycle=[]; bounding=[];

#     for bar in self.bars():
        
#         death_column_entry = bar.death_column()
#         if not death_column_entry is None:
#             death_column_entry = death_column_entry.vertices()

#         bounding_entry = bar.bounding_chain()
#         if not bounding_entry is None:
#             bounding_entry = chain_to_dataframe( bounding_entry )

#         id.append( bar.id_number() )
#         dim.append( bar.dimension() )
#         birth.append( bar.birth() )
#         death.append( bar.death() )
#         birth_column.append( bar.birth_column().vertices() )
#         death_column.append( death_column_entry )
#         cycle.append( chain_to_dataframe( bar.cycle_representative() ) )
#         bounding.append( bounding_entry )
#     data = dict(id=id, dim=dim, birth_fil=birth, death_fil=death, birth_col=birth_column, death_col=death_column, cycle=cycle, bounding=bounding)
#     return pd.DataFrame(data)



