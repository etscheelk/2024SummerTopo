
This folder contains Jupyter notebooks demonstrating the functionality of the Open Applied Topology (OAT) suite in Python.