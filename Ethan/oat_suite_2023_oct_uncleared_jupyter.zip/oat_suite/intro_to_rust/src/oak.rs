//! The description of the oak file goes here.


/// The description of the oak function goes here.
pub fn oak() { println!("I am an oak.") }