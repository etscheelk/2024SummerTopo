//! The description of the willow file goes here.


/// The description of the willow function goes here.
pub fn willow() { println!("I am a willow.") }