//! The description of the cherry file goes here.


/// The description of the cherry function goes here.
pub fn cherry() { println!("I am a cherry blossom.") }