//! The description of the daisy file goes here.


/// The description of the daisy function goes here.
pub fn daisy() { println!("I am a daisy.") }