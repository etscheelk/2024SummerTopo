//! The description of the violoet file goes here.


/// The description of the violoet function goes here.
pub fn violet() { println!("I am a violet.") }