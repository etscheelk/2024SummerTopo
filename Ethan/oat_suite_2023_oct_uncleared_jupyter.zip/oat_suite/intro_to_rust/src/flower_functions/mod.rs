//! The description of the `flower_functions` folder goes here.


pub mod daisy;
pub mod violet;
pub mod blossom_functions;