# Open questions for development


### Matrix view traits

- question
  - how the traits should be structured

- see also
  - documents in the matrices module

- relevant issues

  - as written, we can't implement an oracle on Vec<Vec<(T,U)>> that returns &(T,U)
  - as written, we haven't found a way to implement the oracle traits for Vec<Vec<(T,U)>>, only &'a Vec<Vec<(T,U)>>.  
  - here are some parts to the puzzle:
    - the associated type ViewMajorAscend can't vary depending on the lifetime of the reference &self in the method view_major_ascend( &self, keymaj )
    - one could try a work-around by adding a lifetime to the list of parameters introduced in the trait implementation, but if that lifetime isn't somehow tied to the object then you'll get an error saying that the lifetime parameter is unconstrained, c.f. the following example

      ```ignore
      impl < 'a, N, I, IptrStorage, IndStorage, DataStorage, Iptr >
      
          IndicesAndCoefficients for
      
          CsMatBase
              < N, I, IptrStorage, IndStorage, DataStorage, Iptr > 
      
          where
              I: SpIndex,
              Iptr: SpIndex,
              IptrStorage: Deref<Target = [Iptr]>,
              IndStorage: Deref<Target = [I]>,
              DataStorage: Deref<Target = [N]>, 
              N: 'a,
              I: 'a,
              IptrStorage: 'a,
              IndStorage: 'a,
              DataStorage: 'a,
              Iptr: 'a,        
      {
          type RowIndex=usize; type ColIndex=usize; type Coefficient=&'a N;
      }   
      
      
      impl < 'a, N, I, IptrStorage, IndStorage, DataStorage, Iptr >
          
          ViewRowAscend for 
      
          CsMatBase
              < N, I, IptrStorage, IndStorage, DataStorage, Iptr > 
      
          where
              I: SpIndex,
              Iptr: SpIndex,
              IptrStorage: Deref<Target = [Iptr]>,
              IndStorage: Deref<Target = [I]>,
              DataStorage: Deref<Target = [N]>,      
              N: 'a,
              I: 'a,
              IptrStorage: 'a,
              IndStorage: 'a,
              DataStorage: 'a,
              Iptr: 'a,            
      {
          type ViewMajorAscend            =   VectorIterator<'a, N, I >;
          type ViewMajorAscendIntoIter    =   Self::ViewMajorAscend;
          type EntryMajor =   ( usize, &'a N );
      
          fn view_major_ascend( &self, keymaj: usize ) -> Self::ViewMajorAscend {
              self.outer_view( keymaj ).into_sparse_vec_iter()
          }
      }
      ```


### Matrix arguments as `T` versus `&T`

- question
  - Whether to write functions that take `& OracleStruct` as input and structs that take `& OracleStruct` as fields, or to implement `OracleTrait` for `& OracleStruct` and write functions that take `OracleStruct` as input/structs that store `OracleStruct` as fields.
- relevant issues
  - (serious problem) writing structs that hold `&T` as fields results in lifetime problems.  An example can be found in the `echelon` module.
Here we store an `AntiTranspose` struct inside an echelon solver (namely an `EchelonSolverMajorAscendWithMajorKeys` which is itself stored within a `EchelonSolverMinorDescendWithMinorKeys`).  It might
seem attractive to store only a *reference* to a matrix oracle inside `EchelonSolverMajorAscendWithMajorKeys`, but then you could not write
a function `F` that takes a `MyStruct` as in put and returns a `EchelonSolverMinorDescendWithMinorKeys` as output, because a `EchelonSolverMinorDescendWithMinorKeys`
requires a reference to an `AntiTranspose`, and you can only create an appropriate `AntiTranspose` within the function
call to `F` itself.
  - the `OracleRefInherit` trait is designed to make it more feasible to simply implement oracle traits on references.  This
trait seems mostly successful, with one big drawback, namely that it produces somewhat confusing error messages (rather than
telling you that a struct needs to implement an oracle trait on a `&T`, the compiler may instead tell you that you need to
implement `OracleRefInherit` on `T`.
  - perhaps it's less serious to write functiosn that take `&T` as inputs than it is to write structs that store `&T` in fields?


### Order comaparators to use when working with matrix oracles

- question: should order comparators compare entries (meaning key-val pairs) or just indices?
  - factors to consider
    - a single matrix oracle can have more different entry types than major/minor key types (for example, if you want different entries for ascending verus descending views);
for the purpose of ordering entries, it's therefore attractive to use order comparators that only compare keys (that way you need fewer comparators)
      - on the other hand, in most examples we have seen thus far, the number of entry types is just 2 (= number of key types)
    - the case of using order comparators that compare entries subsumes the case of using order comparators that compare keys; the only real cost is (possibly) using additional type parameters
    - there might be significant performance costs to comparing only keys -- because extracting an key from a key-val pair can incur costs
       - this is because keys can be relatively large (e.g. vectors) and keys can't usually be references, since we need to be able to store keys in vectors
  - current recommendation
    - write low-level functions that compare entries directly; if it's necessary to reduce type parameters for the sake of users,
try to do this for the higher-level functions that the users are more likely to use, rather than the low level things that they may never see
      - this preserves the option to avoid many unnecessary cloning operations
      - it keeps the platform flexible and general (at the potential cost of extra type parameters -- but going the other route would probably incur extra type parameters as well, since we would want to try to "peek" at key values)
      - it avoids the pitfall of trying to avoid a potential problem that, so far, has not proved to be a problem in actuality
    

## Safety

 - consider whether to make the attributes of the MatrixInverseIterator (or whatever it's called) struct private, so that
   the struct can't be constructed incorrectly and can't be modified once it is constructed.  
    - Greg is inclined to accept this proposal.



