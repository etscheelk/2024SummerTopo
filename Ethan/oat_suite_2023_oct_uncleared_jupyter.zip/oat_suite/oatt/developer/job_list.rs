//! To-do items
//!
//! - big ticket items
//!   - implement Arc versions of various constructions for use with Python wrappers:
//!     - COMB's
//!     - iterators
//!   - (long term) write a *trait* for simplices?  for example, this could allow for a different implementation where simplices of smaller dimension are represented by *arrays* which live on the stack, for smaller dimensions
//! 
//! - jobs for open source
//!   - better understand how best to export fractions, possibly using 
//!   - export barcode data to dataframe (c.f. greg's aborted attempt with polars)
//! 
//! - consider whether `enum_dispatch` would improve performance
//! - resolve whether the OracleRef object actually serves a useful purpose, now that the matrix traits have stabilized and we seem to be able to auto-implement them on references
//! - understand why the compiler claims that `Self` has to implemented `Sized` in order to satisfy `IndicesAndCoefficients` in the auto-implementation of the matrix views (plural, as in views_minor_descend) trait
//! - add unit test for "remainder" method in echelon solvers
//! - add the following functions for sparse vector entry iterators, for convenience:
//!     - (low priority) add vectors (with or without specifying precidence function)
//!     - (low priority) a "tuple merge" method allowing one to merge iterators of several different types
//! - use Rust 'Cells' to re-work the iterator heap to work by reference
//! 
//! - Binary search / sorted sequences
//!   - consider setting up a small utility for sets represented by sorted lists (check containment, etc) -- keep in mind that standard Rust tools make actually outperform custom stuff -- cf https://doc.rust-lang.org/stable/std/collections/struct.BTreeMap.html // HOWEVER, in our case we may be a bit different, since sometimes we only need to set up a data structure once and not alter it, so perhaps the custom implementaiton COULD be more efficient"
//!   - COMPARE THIS WITH A (SHORTER? SLICKER?) IMPLEMENTATION HERE https://programming-idioms.org/idiom/124/binary-search-for-a-value-in-sorted-array/2345/rust"
//!   - see also sorted_collections::sortedset::SortedSetExt
//! 
//! - performance testing
//!   - **(EASY) [matrix inversion](crate::matrices::operations::inversion)
//!      VERSUS [sparse triangular solve](crate::matrices::operations::triangular_solve)**.  Geting the `i`th ascending major view of a 
//!     row-major upper triangular matrix or col-major lower triangular matrix is essentially the same as solving `Ax = b` for `x1,
//!     where `b` is a standard unit vector.
//!     - At present, there's no expectation that there should be a significant performance difference between the two 
//!       implementations.  We'll just monitor in case one turns out to be much more effective than the other, at some point
//!       in the future when we have more matrices implemented / a wider range of benchmark examples.
//! 
//! 
//! // plan
//! * to-do
//!   * implement solver for U-match object (Ax = b)
//!   * custom structs for ascending/descending views
//!   * kernel + image basis computation
//!   * bundled matrices (incl. ring operator and order for row, col)
//! * remarks
//!   * saving all the pivots (incl. obvious ones) need not be so bad in dim 1, since
//!     there can't be any more pivots than edges
//!   * why make Mapping::Coefficient a parameter rather than an associated type: maybe it's hard to enforce the rule that Ring<>, Semiring<>, DivisionRing<> all have the same element type?
//! * actions
//!     * !!!! IMPROVE THE EFFICIENCY OF MINOR VIEWS OF VecOfVec; right now they search over a whole row, when they could stop after searching over part of a row
//!     * !!!! HAVEA **DEFAULT** UMATCH FACTORIZATION FUNCTION WHICH IS **SAFE** AND A SEPARATE FUNCTION WITH _unsafe THAT REMOVES SOME CHECKS
//!     * !!!! IMPLEMENT THE FOLLOWING DESIGN DECISION: WE SHOULD ONLY ASK THE UMATCH STRUCT TO STORE ORDER COMPARATORS FOR MAJOR AND MINOR ENTRIES (NOT KEYS) BUT PROVIDE SAFE CONSTRUCTORS THAT ONLY TAKE ORDER COMPARATORS OF INDICES (NOT ENTRIES) AS INPUTS
//!     * !!!! THERE ARE MORE EFFICIENT VERSIONS OF SOME FORMULAE TO RECONSTRUCT THE COMBS THAN REFLECTED IN THEOREM 6 OF THE UMATCH PAPER; for example, to get the matched rows of the of the codomain COMB, you can simply invert the matched block of in the inverse codomain COMB
//!     * !!!! IMPLEMENT a version of MatrixOracleAscend on VecOfVec that returns references to keys and references to values; then use this together with a FilterChangeIndex that takes references for indices to eliminate unnecessary cloning (which happens right now) 
//!     * !!!! the current implementation of CombDomain stores part of the output in a `IterWrappedVec`; there are lazier alternatives, e.g. creating a new struct that stores an iterator and a reference to the matching array, and scales coefficients as needed one at a time as they are returned
//!     * !!!! rather than auto-implement ViewRow for structs that implement ViewRowAscend, create a wrapper object that does the auto-implementation; this avoids conflicting auto-implementations, e.g., if we ever wanted to auto-implement ViewRow for somethng that implements ViewRowDescend
//!     * !!!! for C, first collect the elements of Row_c( A^{-1} ) into a Vec, and sort it; then use the elements of the vect to calculate the linera combination in the righthand block; then write a new vector for the lefthand block; this seems unavoidable due to the fact that the columns of A^{-1} and the columns of D have different key types
//!     * !!!! create "OnlyPivot" and "OnlyNonpivot" objects that subselect pivot/nonpivot elements
//!     * !!!! possibly definte wrapper objects for the major/minor views (just to cut down on the number of type parameters)
//!     * !!!! ADD A CONVERSION FROM VECOFVEC TO VECOFVEC SIMPLE, AND BETWEEN THE REFERENCE VERSIONS
//!     * !!!! Record this technical point: the HitMerge object stores "lower-in-order" iterators towards the front of the internally stored vector; therefore when placing a sequence of vectors in the heap (e.g. when takign a lienar combination of rows or R_{\rho \rho}^{-1}) it might be advantageous to do so in sorted order; this is relevant, for example, to the computation of the inverse of the codomain comb
//!     * !!!! Since we must include an order comparator for major keys, it might be reasonable to include a safety check on the factorization algorithm to ensure that major keys appear in strictly descending order
//!     * !!!! When computing a umatch decomposition (via the function codomain_comb_inv_off_diag_pivot_block_unsafecomparator), each matched row is sorted after its entries are computed; THERE MAY BE A WAY TO STORE THIS MATRIX IN UPPER TRIANGULAR FORM WITHOUT SORTYING -- FOR EXAMPLE, BY ORDERING ELEMENTS ACCORDING TO MINOR KEYS RATHER THAN MAJOR KEYS; THIS COULD SAVEA  LOT OF OPERATIONS, but I'm not sure if it's possible
//!     * !!!! Discuss with Ryan -- when I write an implementation `impl ViewRow for &'a T where T: ViewRow` I get an error for &'a GeneralizedMatchingArrays but not for 
//!     * search library for places where we make trait implementation requirements on a struct/trait implementation that could instead be levied on an individual function or functiosn within that implementation
//!     * add section "Common challenges when implementing matrix oracles," where our approach to lifetimes vis-a-vis the vec-of-vec Rev lifetime problem
//!     * resolve questions:
//!     * remove lifetime parameter from oracle trait?
//!       * are lifetime parameters really necessary for ViewRowDescend?
//!       * why do you need lifetimes for descend but not ascend?
//!     * choose in a TRADEOFF:
//!       * implement oracle trait for `&'a struct` -- this allows one to avoid putting the lifetime in the struct parameters
//!       * be able to use auto_impl(&)
//!     * (once trait specialization stabilizes) print the value that was unsuccessfully pushed to a matching array, in the resulting error message
//!     * integer versus keymaj indexing of Ripiv
//!       - integer indexing
//!         - arguments in favor
//!           - less memory when each entry takes a lot of memory (e.g. vecs)
//!              - and entries only take a small amount of memory in very particular cases (namely low dimensions of simplicial complexes with relatively few vertices)
//!              - also, tuples seem to take relatively little memory, c.f. https://stackoverflow.com/questions/65707981/why-is-the-size-of-a-tuple-or-struct-not-the-sum-of-the-members
//!           - can use vec-of-vec data structure which is more efficient in time/memory than vec-of-vec 
//!             - this makes for a more efficient triangular solve
//!           - easier to transpose
//!         - arguments against
//!           - you have to choose between
//!              - having inverted order of ordinals, or
//!              - reversing order of ordinals; this entains reversing the order of 4 vectors and rewriting ordinals in a vec-of-vec as well as two hash-maps
//!       - integer indexing with adaptor to reverse the indices of entries on the fly
//!         - arguments in favor
//!           - avoids the costly operation of reversing the entries in the whole matrix and reversing the vec-of-vec
//!         - arguments against
//!           - requires a custom data structure
//!           - "more moving parts"
//!       - keymaj indexing
//!         - arguments in favor
//!           - conceptual simplicity
//!           - mathematically natural
//!           - more efficient in the most common use case -- where key and val are stored in the same usize integer 
//!           - same number of hashmaps stored, but no vectors (save 3 vectors worth of data)
//!           - (weak) 
//!         - arguments against
//!           - **this necesitates storing a hashmap from Mapping::RowIndex to Vec.  However we also have to store a hashmap from Mapping::RowIndex to other things for the Matching Array**
//!        
//!   * the current implementation uses Peekable structs to pop out elts of iterators before they're added to hit_merge; this results in
//!     essentially storing one extra entry per iterator; consider exploring ways to drop this extra baggage, e.g. by writing a new hit_merge
//!     function that takes a sequence of `PutBack`s as input, instead of a sequence of iterators
//!     * note also that since we put the peekable structs inside HeadTailHit structs for HitMerge, there really is some redundancy
//!   * the current implementation clones the entries from a selected row of Ripiv each time it eliminates a leading entry; perhaps this can be avoided
//!   * add unit tests for the matching arrays
//!   * rename `OrderingPredicate` and/or `ordering_predicate`
//!   * !!! rather than concatenating vectors to form parts of a row/col of R/Ri/C/Ci, use MERGE (can effect this by using an enum to effectively make a union of two different iterator types)
//!   * add trait with auto-implementation for ring operators to generate 1 and 0 -- put this in the ring file
//!   * add trait with auto-implementation for ring operators to generate minus 1 -- put this in the ring file
//!   * consider imposing consistet rule re: order of arguments (e.g. high to low frequency)
//!   * (in general) go back through existing code and remove Mapping::Coefficient parametr (reducundant with the RingOperator parameter)
//!   * (in general) make two versions of any given object: one private+safe, and one public+unsafe+modifiable
//!   * (maybe) modify the inversion struct so that it doesn't constantly re-write the "head" entry
//!   * (development goal) make it possible for people to write their own matrix oracle in python / export to exhact?
//!   * (GOAL) make tutorials / demos a central, constant part of development goal
//!   * enforce a rule that the structural nz entries in a VecOfVec must be nonzero?
//! * structs
//!   * Ri_piv -- probably want to make this a REFERENCE since some computations call for mulptiple copies
//!   * VecOfVecUnitriangular
//!   * ReductionMatrixConstructor
//!      * iterates over "rows" of the reduction matrix in order
//!      * each item is an iterator that iterates over a row
//!      * after a row is generated, it's added to the internally stored VecOfVec, and the remaining 
//!        coefficient gets saved to the internally-stored matching array
//!      * potential differences with the ViewAscendingInverse struct
//!        * modifies the matrix oracle from which it draws eliminating iterators
//!        * writes its output to an internally stored attribute
//!        * stores other, additional information at each step, too (e.g. the matching array)
//! * optional to-do
//!   * make small utility library for sets repesented by ordered lists     
//! DONE
//!   * !!! consider switching order of Mapping::ColIndex and Mapping::RowIndex