# Diff Summary

Date : 2023-04-12 19:13:37

Directory /Users/roek189/Library/CloudStorage/OneDrive-PNNL/Desktop/a/r/c/l/multi/oat/oat_suite/solar

Total : 0 files,  0 codes, 0 comments, 0 blanks, all 0 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)