# Summary

Date : 2023-04-12 19:13:37

Directory /Users/roek189/Library/CloudStorage/OneDrive-PNNL/Desktop/a/r/c/l/multi/oat/oat_suite/solar

Total : 94 files,  14124 codes, 10480 comments, 5846 blanks, all 30450 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Rust | 89 | 14,049 | 10,480 | 5,803 | 30,332 |
| Markdown | 5 | 75 | 0 | 43 | 118 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 94 | 14,124 | 10,480 | 5,846 | 30,450 |
| . (Files) | 4 | 72 | 0 | 40 | 112 |
| src | 90 | 14,052 | 10,480 | 5,806 | 30,338 |
| src (Files) | 2 | 10 | 341 | 9 | 360 |
| src/bin | 1 | 3 | 0 | 4 | 7 |
| src/chains | 3 | 501 | 162 | 95 | 758 |
| src/developer | 5 | 4 | 236 | 3 | 243 |
| src/matrices | 39 | 9,861 | 6,025 | 4,016 | 19,902 |
| src/matrices (Files) | 6 | 587 | 565 | 267 | 1,419 |
| src/matrices/help | 5 | 4 | 413 | 4 | 421 |
| src/matrices/operations | 15 | 7,645 | 3,632 | 2,728 | 14,005 |
| src/matrices/operations (Files) | 7 | 1,655 | 904 | 632 | 3,191 |
| src/matrices/operations/solve | 3 | 1,178 | 500 | 433 | 2,111 |
| src/matrices/operations/umatch | 5 | 4,812 | 2,228 | 1,663 | 8,703 |
| src/matrices/types | 13 | 1,625 | 1,415 | 1,017 | 4,057 |
| src/rings | 5 | 422 | 448 | 163 | 1,033 |
| src/rings (Files) | 2 | 57 | 131 | 51 | 239 |
| src/rings/operator_structs | 3 | 365 | 317 | 112 | 794 |
| src/tutorials | 7 | 6 | 557 | 36 | 599 |
| src/utilities | 22 | 2,314 | 1,839 | 1,080 | 5,233 |
| src/utilities (Files) | 10 | 872 | 680 | 407 | 1,959 |
| src/utilities/functions | 4 | 384 | 328 | 235 | 947 |
| src/utilities/heaps | 2 | 175 | 172 | 71 | 418 |
| src/utilities/iterators | 6 | 883 | 659 | 367 | 1,909 |
| src/utilities/iterators (Files) | 3 | 525 | 345 | 222 | 1,092 |
| src/utilities/iterators/merge | 3 | 358 | 314 | 145 | 817 |
| src/vectors | 6 | 931 | 872 | 400 | 2,203 |
| src/vectors (Files) | 4 | 919 | 871 | 392 | 2,182 |
| src/vectors/implementors | 2 | 12 | 1 | 8 | 21 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)