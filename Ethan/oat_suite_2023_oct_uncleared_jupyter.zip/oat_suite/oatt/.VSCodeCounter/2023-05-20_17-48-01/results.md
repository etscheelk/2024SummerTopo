# Summary

Date : 2023-05-20 17:48:01

Directory /Users/roek189/Library/CloudStorage/OneDrive-PNNL/Desktop/a/r/c/l/multi/oat/oat_suite/solar

Total : 137 files,  19739 codes, 15906 comments, 8026 blanks, all 43671 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Rust | 124 | 19,236 | 15,906 | 7,885 | 43,027 |
| Markdown | 13 | 503 | 0 | 141 | 644 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 137 | 19,739 | 15,906 | 8,026 | 43,671 |
| . (Files) | 6 | 99 | 0 | 50 | 149 |
| developer | 8 | 399 | 188 | 85 | 672 |
| developer (Files) | 7 | 302 | 188 | 60 | 550 |
| developer/design | 1 | 97 | 0 | 25 | 122 |
| src | 121 | 19,232 | 15,718 | 7,883 | 42,833 |
| src (Files) | 2 | 7 | 361 | 10 | 378 |
| src/algebra | 54 | 11,917 | 8,034 | 4,465 | 24,416 |
| src/algebra (Files) | 1 | 4 | 3 | 2 | 9 |
| src/algebra/chains | 3 | 614 | 246 | 125 | 985 |
| src/algebra/matrices | 39 | 9,562 | 5,926 | 3,698 | 19,186 |
| src/algebra/matrices (Files) | 7 | 957 | 902 | 409 | 2,268 |
| src/algebra/matrices/help | 4 | 3 | 397 | 4 | 404 |
| src/algebra/matrices/operations | 14 | 6,535 | 3,011 | 2,243 | 11,789 |
| src/algebra/matrices/operations (Files) | 7 | 1,707 | 921 | 638 | 3,266 |
| src/algebra/matrices/operations/solve | 3 | 1,277 | 585 | 475 | 2,337 |
| src/algebra/matrices/operations/umatch | 4 | 3,551 | 1,505 | 1,130 | 6,186 |
| src/algebra/matrices/types | 14 | 2,067 | 1,616 | 1,042 | 4,725 |
| src/algebra/rings | 5 | 423 | 489 | 173 | 1,085 |
| src/algebra/rings (Files) | 2 | 57 | 131 | 51 | 239 |
| src/algebra/rings/operator_structs | 3 | 366 | 358 | 122 | 846 |
| src/algebra/vectors | 6 | 1,314 | 1,370 | 467 | 3,151 |
| src/algebra/vectors (Files) | 4 | 1,302 | 1,369 | 459 | 3,130 |
| src/algebra/vectors/implementors | 2 | 12 | 1 | 8 | 21 |
| src/bin | 1 | 3 | 0 | 4 | 7 |
| src/topology | 23 | 3,454 | 2,907 | 1,618 | 7,979 |
| src/topology (Files) | 3 | 261 | 150 | 86 | 497 |
| src/topology/bin | 2 | 76 | 63 | 45 | 184 |
| src/topology/simplicial | 16 | 3,086 | 2,686 | 1,478 | 7,250 |
| src/topology/simplicial (Files) | 2 | 157 | 181 | 98 | 436 |
| src/topology/simplicial/from | 8 | 2,397 | 2,194 | 1,170 | 5,761 |
| src/topology/simplicial/from (Files) | 7 | 2,397 | 2,164 | 1,170 | 5,731 |
| src/topology/simplicial/from/relation_weighted | 1 | 0 | 30 | 0 | 30 |
| src/topology/simplicial/misc | 2 | 57 | 52 | 32 | 141 |
| src/topology/simplicial/simplices | 4 | 475 | 259 | 178 | 912 |
| src/topology/zigzag | 2 | 31 | 8 | 9 | 48 |
| src/tutorials | 10 | 8 | 1,240 | 140 | 1,388 |
| src/tutorials (Files) | 5 | 4 | 1,073 | 129 | 1,206 |
| src/tutorials/rust | 5 | 4 | 167 | 11 | 182 |
| src/utilities | 31 | 3,843 | 3,176 | 1,646 | 8,665 |
| src/utilities (Files) | 10 | 934 | 781 | 436 | 2,151 |
| src/utilities/functions | 3 | 382 | 327 | 236 | 945 |
| src/utilities/heaps | 2 | 175 | 172 | 71 | 418 |
| src/utilities/iterators | 8 | 1,307 | 1,064 | 522 | 2,893 |
| src/utilities/iterators (Files) | 3 | 587 | 391 | 235 | 1,213 |
| src/utilities/iterators/merge | 5 | 720 | 673 | 287 | 1,680 |
| src/utilities/optimization | 8 | 1,045 | 832 | 381 | 2,258 |
| src/utilities/optimization (Files) | 6 | 834 | 594 | 304 | 1,732 |
| src/utilities/optimization/gurobi | 2 | 211 | 238 | 77 | 526 |
| user | 2 | 9 | 0 | 8 | 17 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)