# Diff Summary

Date : 2023-05-20 17:48:01

Directory /Users/roek189/Library/CloudStorage/OneDrive-PNNL/Desktop/a/r/c/l/multi/oat/oat_suite/solar

Total : 185 files,  5258 codes, 5139 comments, 2055 blanks, all 12452 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Rust | 174 | 4,830 | 5,139 | 1,957 | 11,926 |
| Markdown | 11 | 428 | 0 | 98 | 526 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 185 | 5,258 | 5,139 | 2,055 | 12,452 |
| . (Files) | 3 | 27 | 0 | 10 | 37 |
| developer | 8 | 399 | 188 | 85 | 672 |
| developer (Files) | 7 | 302 | 188 | 60 | 550 |
| developer/design | 1 | 97 | 0 | 25 | 122 |
| src | 172 | 4,823 | 4,951 | 1,952 | 11,726 |
| src (Files) | 1 | -3 | 20 | 1 | 18 |
| src/algebra | 54 | 11,917 | 8,034 | 4,465 | 24,416 |
| src/algebra (Files) | 1 | 4 | 3 | 2 | 9 |
| src/algebra/chains | 3 | 614 | 246 | 125 | 985 |
| src/algebra/matrices | 39 | 9,562 | 5,926 | 3,698 | 19,186 |
| src/algebra/matrices (Files) | 7 | 957 | 902 | 409 | 2,268 |
| src/algebra/matrices/help | 4 | 3 | 397 | 4 | 404 |
| src/algebra/matrices/operations | 14 | 6,535 | 3,011 | 2,243 | 11,789 |
| src/algebra/matrices/operations (Files) | 7 | 1,707 | 921 | 638 | 3,266 |
| src/algebra/matrices/operations/solve | 3 | 1,277 | 585 | 475 | 2,337 |
| src/algebra/matrices/operations/umatch | 4 | 3,551 | 1,505 | 1,130 | 6,186 |
| src/algebra/matrices/types | 14 | 2,067 | 1,616 | 1,042 | 4,725 |
| src/algebra/rings | 5 | 423 | 489 | 173 | 1,085 |
| src/algebra/rings (Files) | 2 | 57 | 131 | 51 | 239 |
| src/algebra/rings/operator_structs | 3 | 366 | 358 | 122 | 846 |
| src/algebra/vectors | 6 | 1,314 | 1,370 | 467 | 3,151 |
| src/algebra/vectors (Files) | 4 | 1,302 | 1,369 | 459 | 3,130 |
| src/algebra/vectors/implementors | 2 | 12 | 1 | 8 | 21 |
| src/chains | 3 | -559 | -199 | -112 | -870 |
| src/developer | 5 | -4 | -248 | -3 | -255 |
| src/matrices | 41 | -10,110 | -6,169 | -4,107 | -20,386 |
| src/matrices (Files) | 7 | -854 | -683 | -357 | -1,894 |
| src/matrices/help | 5 | -4 | -413 | -4 | -421 |
| src/matrices/operations | 15 | -7,621 | -3,657 | -2,728 | -14,006 |
| src/matrices/operations (Files) | 7 | -1,655 | -904 | -632 | -3,191 |
| src/matrices/operations/solve | 3 | -1,178 | -500 | -433 | -2,111 |
| src/matrices/operations/umatch | 5 | -4,788 | -2,253 | -1,663 | -8,704 |
| src/matrices/types | 14 | -1,631 | -1,416 | -1,018 | -4,065 |
| src/rings | 5 | -422 | -448 | -163 | -1,033 |
| src/rings (Files) | 2 | -57 | -131 | -51 | -239 |
| src/rings/operator_structs | 3 | -365 | -317 | -112 | -794 |
| src/topology | 23 | 3,454 | 2,907 | 1,618 | 7,979 |
| src/topology (Files) | 3 | 261 | 150 | 86 | 497 |
| src/topology/bin | 2 | 76 | 63 | 45 | 184 |
| src/topology/simplicial | 16 | 3,086 | 2,686 | 1,478 | 7,250 |
| src/topology/simplicial (Files) | 2 | 157 | 181 | 98 | 436 |
| src/topology/simplicial/from | 8 | 2,397 | 2,194 | 1,170 | 5,761 |
| src/topology/simplicial/from (Files) | 7 | 2,397 | 2,164 | 1,170 | 5,731 |
| src/topology/simplicial/from/relation_weighted | 1 | 0 | 30 | 0 | 30 |
| src/topology/simplicial/misc | 2 | 57 | 52 | 32 | 141 |
| src/topology/simplicial/simplices | 4 | 475 | 259 | 178 | 912 |
| src/topology/zigzag | 2 | 31 | 8 | 9 | 48 |
| src/tutorials | 12 | 2 | 683 | 104 | 789 |
| src/tutorials (Files) | 7 | -2 | 516 | 93 | 607 |
| src/tutorials/rust | 5 | 4 | 167 | 11 | 182 |
| src/utilities | 22 | 1,479 | 1,243 | 549 | 3,271 |
| src/utilities (Files) | 6 | 25 | 18 | 13 | 56 |
| src/utilities/functions | 3 | -2 | -1 | 1 | -2 |
| src/utilities/iterators | 5 | 411 | 394 | 154 | 959 |
| src/utilities/iterators (Files) | 1 | 52 | 35 | 11 | 98 |
| src/utilities/iterators/merge | 4 | 359 | 359 | 143 | 861 |
| src/utilities/optimization | 8 | 1,045 | 832 | 381 | 2,258 |
| src/utilities/optimization (Files) | 6 | 834 | 594 | 304 | 1,732 |
| src/utilities/optimization/gurobi | 2 | 211 | 238 | 77 | 526 |
| src/vectors | 6 | -931 | -872 | -400 | -2,203 |
| src/vectors (Files) | 4 | -919 | -871 | -392 | -2,182 |
| src/vectors/implementors | 2 | -12 | -1 | -8 | -21 |
| user | 2 | 9 | 0 | 8 | 17 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)