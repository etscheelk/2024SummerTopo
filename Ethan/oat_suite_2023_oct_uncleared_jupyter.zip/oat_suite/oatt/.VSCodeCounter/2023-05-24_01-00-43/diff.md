# Diff Summary

Date : 2023-05-24 01:00:43

Directory /Users/roek189/Library/CloudStorage/OneDrive-PNNL/Desktop/a/r/c/l/multi/oat/oat_suite/solar

Total : 25 files,  1456 codes, 1493 comments, 435 blanks, all 3384 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Rust | 24 | 1,455 | 1,493 | 436 | 3,384 |
| Markdown | 1 | 1 | 0 | -1 | 0 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 25 | 1,456 | 1,493 | 435 | 3,384 |
| developer | 1 | 1 | 0 | -1 | 0 |
| src | 24 | 1,455 | 1,493 | 436 | 3,384 |
| src (Files) | 1 | 0 | 1 | 0 | 1 |
| src/algebra | 17 | 1,118 | 1,177 | 277 | 2,572 |
| src/algebra/chains | 1 | 10 | 5 | 1 | 16 |
| src/algebra/matrices | 13 | 1,123 | 1,106 | 273 | 2,502 |
| src/algebra/matrices (Files) | 2 | 1 | -2 | 1 | 0 |
| src/algebra/matrices/help | 1 | 0 | 3 | 0 | 3 |
| src/algebra/matrices/operations | 8 | 865 | 1,035 | 232 | 2,132 |
| src/algebra/matrices/operations (Files) | 2 | 92 | 55 | 22 | 169 |
| src/algebra/matrices/operations/solve | 1 | 271 | 465 | 107 | 843 |
| src/algebra/matrices/operations/umatch | 5 | 502 | 515 | 103 | 1,120 |
| src/algebra/matrices/operations/umatch (Files) | 2 | -3,334 | -1,340 | -1,075 | -5,749 |
| src/algebra/matrices/operations/umatch/row_major | 3 | 3,836 | 1,855 | 1,178 | 6,869 |
| src/algebra/matrices/types | 2 | 257 | 70 | 40 | 367 |
| src/algebra/vectors | 3 | -15 | 66 | 3 | 54 |
| src/topology | 1 | 1 | 0 | 0 | 1 |
| src/topology/simplicial | 1 | 1 | 0 | 0 | 1 |
| src/topology/simplicial/from | 1 | 1 | 0 | 0 | 1 |
| src/utilities | 5 | 336 | 315 | 159 | 810 |
| src/utilities (Files) | 2 | 19 | 24 | 11 | 54 |
| src/utilities/functions | 1 | 51 | 79 | 29 | 159 |
| src/utilities/iterators | 2 | 266 | 212 | 119 | 597 |
| src/utilities/iterators (Files) | 1 | 266 | 210 | 119 | 595 |
| src/utilities/iterators/merge | 1 | 0 | 2 | 0 | 2 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)