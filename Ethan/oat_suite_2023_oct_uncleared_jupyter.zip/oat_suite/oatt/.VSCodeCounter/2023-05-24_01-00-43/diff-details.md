# Diff Details

Date : 2023-05-24 01:00:43

Directory /Users/roek189/Library/CloudStorage/OneDrive-PNNL/Desktop/a/r/c/l/multi/oat/oat_suite/solar

Total : 25 files,  1456 codes, 1493 comments, 435 blanks, all 3384 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [developer/job_list.md](/developer/job_list.md) | Markdown | 1 | 0 | -1 | 0 |
| [src/algebra/chains/factored.rs](/src/algebra/chains/factored.rs) | Rust | 10 | 5 | 1 | 16 |
| [src/algebra/matrices/help/creating_new_matrix_types.rs](/src/algebra/matrices/help/creating_new_matrix_types.rs) | Rust | 0 | 3 | 0 | 3 |
| [src/algebra/matrices/mod.rs](/src/algebra/matrices/mod.rs) | Rust | 0 | -2 | 0 | -2 |
| [src/algebra/matrices/operations/mod.rs](/src/algebra/matrices/operations/mod.rs) | Rust | 104 | 44 | 24 | 172 |
| [src/algebra/matrices/operations/multiply.rs](/src/algebra/matrices/operations/multiply.rs) | Rust | -12 | 11 | -2 | -3 |
| [src/algebra/matrices/operations/solve/echelon.rs](/src/algebra/matrices/operations/solve/echelon.rs) | Rust | 271 | 465 | 107 | 843 |
| [src/algebra/matrices/operations/umatch/mod.rs](/src/algebra/matrices/operations/umatch/mod.rs) | Rust | 0 | 2 | 0 | 2 |
| [src/algebra/matrices/operations/umatch/row_major.rs](/src/algebra/matrices/operations/umatch/row_major.rs) | Rust | -3,334 | -1,342 | -1,075 | -5,751 |
| [src/algebra/matrices/operations/umatch/row_major/comb.rs](/src/algebra/matrices/operations/umatch/row_major/comb.rs) | Rust | 1,351 | 664 | 366 | 2,381 |
| [src/algebra/matrices/operations/umatch/row_major/construction.rs](/src/algebra/matrices/operations/umatch/row_major/construction.rs) | Rust | 650 | 331 | 254 | 1,235 |
| [src/algebra/matrices/operations/umatch/row_major/mod.rs](/src/algebra/matrices/operations/umatch/row_major/mod.rs) | Rust | 1,835 | 860 | 558 | 3,253 |
| [src/algebra/matrices/query.rs](/src/algebra/matrices/query.rs) | Rust | 1 | 0 | 1 | 2 |
| [src/algebra/matrices/types/matching.rs](/src/algebra/matrices/types/matching.rs) | Rust | 77 | 59 | 10 | 146 |
| [src/algebra/matrices/types/packet.rs](/src/algebra/matrices/types/packet.rs) | Rust | 180 | 11 | 30 | 221 |
| [src/algebra/vectors/linear_combinations.rs](/src/algebra/vectors/linear_combinations.rs) | Rust | -164 | -43 | -38 | -245 |
| [src/algebra/vectors/mod.rs](/src/algebra/vectors/mod.rs) | Rust | 1 | 1 | 7 | 9 |
| [src/algebra/vectors/operations.rs](/src/algebra/vectors/operations.rs) | Rust | 148 | 108 | 34 | 290 |
| [src/lib.rs](/src/lib.rs) | Rust | 0 | 1 | 0 | 1 |
| [src/topology/simplicial/from/graph_weighted.rs](/src/topology/simplicial/from/graph_weighted.rs) | Rust | 1 | 0 | 0 | 1 |
| [src/utilities/functions/evaluate.rs](/src/utilities/functions/evaluate.rs) | Rust | 51 | 79 | 29 | 159 |
| [src/utilities/iterators/general.rs](/src/utilities/iterators/general.rs) | Rust | 266 | 210 | 119 | 595 |
| [src/utilities/iterators/merge/hit.rs](/src/utilities/iterators/merge/hit.rs) | Rust | 0 | 2 | 0 | 2 |
| [src/utilities/sequences_and_ordinals.rs](/src/utilities/sequences_and_ordinals.rs) | Rust | 1 | 0 | 0 | 1 |
| [src/utilities/sets.rs](/src/utilities/sets.rs) | Rust | 18 | 24 | 11 | 53 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details