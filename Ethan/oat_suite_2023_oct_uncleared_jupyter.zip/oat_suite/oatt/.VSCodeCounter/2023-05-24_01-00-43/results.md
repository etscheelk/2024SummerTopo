# Summary

Date : 2023-05-24 01:00:43

Directory /Users/roek189/Library/CloudStorage/OneDrive-PNNL/Desktop/a/r/c/l/multi/oat/oat_suite/solar

Total : 138 files,  21195 codes, 17399 comments, 8461 blanks, all 47055 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Rust | 125 | 20,691 | 17,399 | 8,321 | 46,411 |
| Markdown | 13 | 504 | 0 | 140 | 644 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 138 | 21,195 | 17,399 | 8,461 | 47,055 |
| . (Files) | 6 | 99 | 0 | 50 | 149 |
| developer | 8 | 400 | 188 | 84 | 672 |
| developer (Files) | 7 | 303 | 188 | 59 | 550 |
| developer/design | 1 | 97 | 0 | 25 | 122 |
| src | 122 | 20,687 | 17,211 | 8,319 | 46,217 |
| src (Files) | 2 | 7 | 362 | 10 | 379 |
| src/algebra | 55 | 13,035 | 9,211 | 4,742 | 26,988 |
| src/algebra (Files) | 1 | 4 | 3 | 2 | 9 |
| src/algebra/chains | 3 | 624 | 251 | 126 | 1,001 |
| src/algebra/matrices | 41 | 10,685 | 7,032 | 3,971 | 21,688 |
| src/algebra/matrices (Files) | 7 | 958 | 900 | 410 | 2,268 |
| src/algebra/matrices/help | 4 | 3 | 400 | 4 | 407 |
| src/algebra/matrices/operations | 16 | 7,400 | 4,046 | 2,475 | 13,921 |
| src/algebra/matrices/operations (Files) | 7 | 1,799 | 976 | 660 | 3,435 |
| src/algebra/matrices/operations/solve | 3 | 1,548 | 1,050 | 582 | 3,180 |
| src/algebra/matrices/operations/umatch | 6 | 4,053 | 2,020 | 1,233 | 7,306 |
| src/algebra/matrices/operations/umatch (Files) | 3 | 217 | 165 | 55 | 437 |
| src/algebra/matrices/operations/umatch/row_major | 3 | 3,836 | 1,855 | 1,178 | 6,869 |
| src/algebra/matrices/types | 14 | 2,324 | 1,686 | 1,082 | 5,092 |
| src/algebra/rings | 5 | 423 | 489 | 173 | 1,085 |
| src/algebra/rings (Files) | 2 | 57 | 131 | 51 | 239 |
| src/algebra/rings/operator_structs | 3 | 366 | 358 | 122 | 846 |
| src/algebra/vectors | 5 | 1,299 | 1,436 | 470 | 3,205 |
| src/algebra/vectors (Files) | 3 | 1,287 | 1,435 | 462 | 3,184 |
| src/algebra/vectors/implementors | 2 | 12 | 1 | 8 | 21 |
| src/bin | 1 | 3 | 0 | 4 | 7 |
| src/topology | 23 | 3,455 | 2,907 | 1,618 | 7,980 |
| src/topology (Files) | 3 | 261 | 150 | 86 | 497 |
| src/topology/bin | 2 | 76 | 63 | 45 | 184 |
| src/topology/simplicial | 16 | 3,087 | 2,686 | 1,478 | 7,251 |
| src/topology/simplicial (Files) | 2 | 157 | 181 | 98 | 436 |
| src/topology/simplicial/from | 8 | 2,398 | 2,194 | 1,170 | 5,762 |
| src/topology/simplicial/from (Files) | 7 | 2,398 | 2,164 | 1,170 | 5,732 |
| src/topology/simplicial/from/relation_weighted | 1 | 0 | 30 | 0 | 30 |
| src/topology/simplicial/misc | 2 | 57 | 52 | 32 | 141 |
| src/topology/simplicial/simplices | 4 | 475 | 259 | 178 | 912 |
| src/topology/zigzag | 2 | 31 | 8 | 9 | 48 |
| src/tutorials | 10 | 8 | 1,240 | 140 | 1,388 |
| src/tutorials (Files) | 5 | 4 | 1,073 | 129 | 1,206 |
| src/tutorials/rust | 5 | 4 | 167 | 11 | 182 |
| src/utilities | 31 | 4,179 | 3,491 | 1,805 | 9,475 |
| src/utilities (Files) | 10 | 953 | 805 | 447 | 2,205 |
| src/utilities/functions | 3 | 433 | 406 | 265 | 1,104 |
| src/utilities/heaps | 2 | 175 | 172 | 71 | 418 |
| src/utilities/iterators | 8 | 1,573 | 1,276 | 641 | 3,490 |
| src/utilities/iterators (Files) | 3 | 853 | 601 | 354 | 1,808 |
| src/utilities/iterators/merge | 5 | 720 | 675 | 287 | 1,682 |
| src/utilities/optimization | 8 | 1,045 | 832 | 381 | 2,258 |
| src/utilities/optimization (Files) | 6 | 834 | 594 | 304 | 1,732 |
| src/utilities/optimization/gurobi | 2 | 211 | 238 | 77 | 526 |
| user | 2 | 9 | 0 | 8 | 17 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)