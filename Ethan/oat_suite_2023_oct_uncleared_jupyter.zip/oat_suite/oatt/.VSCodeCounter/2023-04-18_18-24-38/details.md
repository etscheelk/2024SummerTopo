# Details

Date : 2023-04-18 18:24:38

Directory /Users/roek189/Library/CloudStorage/OneDrive-PNNL/Desktop/a/r/c/l/multi/oat/oat_suite/solar

Total : 96 files,  14481 codes, 10767 comments, 5971 blanks, all 31219 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [CONTRIBUTING.md](/CONTRIBUTING.md) | Markdown | 41 | 0 | 21 | 62 |
| [DISCLAIMER.md](/DISCLAIMER.md) | Markdown | 7 | 0 | 1 | 8 |
| [LICENSE.md](/LICENSE.md) | Markdown | 6 | 0 | 3 | 9 |
| [README.md](/README.md) | Markdown | 18 | 0 | 15 | 33 |
| [src/bin/reusable_file_to_debug.rs](/src/bin/reusable_file_to_debug.rs) | Rust | 3 | 0 | 4 | 7 |
| [src/chains/factored.rs](/src/chains/factored.rs) | Rust | 331 | 138 | 68 | 537 |
| [src/chains/jordan.rs](/src/chains/jordan.rs) | Rust | 226 | 60 | 43 | 329 |
| [src/chains/mod.rs](/src/chains/mod.rs) | Rust | 2 | 1 | 1 | 4 |
| [src/developer/guidelines.rs](/src/developer/guidelines.rs) | Rust | 0 | 53 | 1 | 54 |
| [src/developer/job_list.rs](/src/developer/job_list.rs) | Rust | 0 | 130 | 0 | 130 |
| [src/developer/mod.rs](/src/developer/mod.rs) | Rust | 4 | 1 | 1 | 6 |
| [src/developer/open_questions.rs](/src/developer/open_questions.rs) | Rust | 0 | 50 | 1 | 51 |
| [src/developer/rust_debugging.rs](/src/developer/rust_debugging.rs) | Rust | 0 | 14 | 0 | 14 |
| [src/lib.rs](/src/lib.rs) | Rust | 7 | 334 | 4 | 345 |
| [src/main.rs](/src/main.rs) | Rust | 3 | 7 | 5 | 15 |
| [src/matrices/debug.rs](/src/matrices/debug.rs) | Rust | 218 | 28 | 31 | 277 |
| [src/matrices/developer.rs](/src/matrices/developer.rs) | Rust | 0 | 52 | 1 | 53 |
| [src/matrices/developer_notes.rs](/src/matrices/developer_notes.rs) | Rust | 0 | 52 | 1 | 53 |
| [src/matrices/display.rs](/src/matrices/display.rs) | Rust | 48 | 29 | 21 | 98 |
| [src/matrices/help/common_challenges.rs](/src/matrices/help/common_challenges.rs) | Rust | 0 | 16 | 0 | 16 |
| [src/matrices/help/creating_new_matrix_types.rs](/src/matrices/help/creating_new_matrix_types.rs) | Rust | 0 | 374 | 0 | 374 |
| [src/matrices/help/mod.rs](/src/matrices/help/mod.rs) | Rust | 4 | 1 | 2 | 7 |
| [src/matrices/help/trouble_shooting.rs](/src/matrices/help/trouble_shooting.rs) | Rust | 0 | 14 | 1 | 15 |
| [src/matrices/help/working_with_matrices.rs](/src/matrices/help/working_with_matrices.rs) | Rust | 0 | 8 | 1 | 9 |
| [src/matrices/mod.rs](/src/matrices/mod.rs) | Rust | 8 | 69 | 2 | 79 |
| [src/matrices/operations/invert.rs](/src/matrices/operations/invert.rs) | Rust | 363 | 240 | 140 | 743 |
| [src/matrices/operations/mod.rs](/src/matrices/operations/mod.rs) | Rust | 8 | 2 | 1 | 11 |
| [src/matrices/operations/multiply.rs](/src/matrices/operations/multiply.rs) | Rust | 524 | 346 | 172 | 1,042 |
| [src/matrices/operations/solve/echelon.rs](/src/matrices/operations/solve/echelon.rs) | Rust | 915 | 395 | 328 | 1,638 |
| [src/matrices/operations/solve/mod.rs](/src/matrices/operations/solve/mod.rs) | Rust | 2 | 3 | 2 | 7 |
| [src/matrices/operations/solve/triangle.rs](/src/matrices/operations/solve/triangle.rs) | Rust | 261 | 102 | 103 | 466 |
| [src/matrices/operations/transform_entry_wise.rs](/src/matrices/operations/transform_entry_wise.rs) | Rust | 171 | 73 | 85 | 329 |
| [src/matrices/operations/transform_vector_wise.rs](/src/matrices/operations/transform_vector_wise.rs) | Rust | 404 | 119 | 176 | 699 |
| [src/matrices/operations/transpose.rs](/src/matrices/operations/transpose.rs) | Rust | 0 | 1 | 0 | 1 |
| [src/matrices/operations/umatch/developer.rs](/src/matrices/operations/umatch/developer.rs) | Rust | 0 | 88 | 0 | 88 |
| [src/matrices/operations/umatch/diagnostics.rs](/src/matrices/operations/umatch/diagnostics.rs) | Rust | 215 | 42 | 52 | 309 |
| [src/matrices/operations/umatch/mod.rs](/src/matrices/operations/umatch/mod.rs) | Rust | 2 | 33 | 3 | 38 |
| [src/matrices/operations/umatch/row_major.rs](/src/matrices/operations/umatch/row_major.rs) | Rust | 2,965 | 1,227 | 997 | 5,189 |
| [src/matrices/operations/umatch/row_major_only.rs](/src/matrices/operations/umatch/row_major_only.rs) | Rust | 1,606 | 863 | 611 | 3,080 |
| [src/matrices/operations/vec_of_vec_reduction.rs](/src/matrices/operations/vec_of_vec_reduction.rs) | Rust | 185 | 123 | 58 | 366 |
| [src/matrices/query.rs](/src/matrices/query.rs) | Rust | 470 | 417 | 271 | 1,158 |
| [src/matrices/random_constructors.rs](/src/matrices/random_constructors.rs) | Rust | 110 | 36 | 30 | 176 |
| [src/matrices/types/ESSENTIAL_TO_DO.md](/src/matrices/types/ESSENTIAL_TO_DO.md) | Markdown | 3 | 0 | 3 | 6 |
| [src/matrices/types/compressed_sparse.rs](/src/matrices/types/compressed_sparse.rs) | Rust | 0 | 9 | 3 | 12 |
| [src/matrices/types/csm.rs](/src/matrices/types/csm.rs) | Rust | 0 | 7 | 0 | 7 |
| [src/matrices/types/dense.rs](/src/matrices/types/dense.rs) | Rust | 0 | 0 | 1 | 1 |
| [src/matrices/types/hash_of_vec.rs](/src/matrices/types/hash_of_vec.rs) | Rust | 30 | 24 | 27 | 81 |
| [src/matrices/types/matching.rs](/src/matrices/types/matching.rs) | Rust | 418 | 267 | 177 | 862 |
| [src/matrices/types/mod.rs](/src/matrices/types/mod.rs) | Rust | 8 | 1 | 2 | 11 |
| [src/matrices/types/oracle_deref.rs](/src/matrices/types/oracle_deref.rs) | Rust | 100 | 229 | 186 | 515 |
| [src/matrices/types/oracle_ref.rs](/src/matrices/types/oracle_ref.rs) | Rust | 87 | 15 | 50 | 152 |
| [src/matrices/types/prepend_viewmaj.rs](/src/matrices/types/prepend_viewmaj.rs) | Rust | 99 | 51 | 56 | 206 |
| [src/matrices/types/scalar_matrices.rs](/src/matrices/types/scalar_matrices.rs) | Rust | 128 | 250 | 89 | 467 |
| [src/matrices/types/transpose.rs](/src/matrices/types/transpose.rs) | Rust | 121 | 85 | 124 | 330 |
| [src/matrices/types/vec_of_csvec.rs](/src/matrices/types/vec_of_csvec.rs) | Rust | 27 | 1 | 9 | 37 |
| [src/matrices/types/vec_of_vec.rs](/src/matrices/types/vec_of_vec.rs) | Rust | 610 | 477 | 291 | 1,378 |
| [src/rings/mod.rs](/src/rings/mod.rs) | Rust | 2 | 80 | 2 | 84 |
| [src/rings/operator_structs/field_prime_order.rs](/src/rings/operator_structs/field_prime_order.rs) | Rust | 135 | 177 | 70 | 382 |
| [src/rings/operator_structs/mod.rs](/src/rings/operator_structs/mod.rs) | Rust | 2 | 1 | 1 | 4 |
| [src/rings/operator_structs/ring_native.rs](/src/rings/operator_structs/ring_native.rs) | Rust | 228 | 139 | 41 | 408 |
| [src/rings/operator_traits.rs](/src/rings/operator_traits.rs) | Rust | 55 | 51 | 49 | 155 |
| [src/tutorials/matrix_oracle_first_steps.rs](/src/tutorials/matrix_oracle_first_steps.rs) | Rust | 0 | 209 | 23 | 232 |
| [src/tutorials/mod.rs](/src/tutorials/mod.rs) | Rust | 6 | 2 | 1 | 9 |
| [src/tutorials/rust_workflow.rs](/src/tutorials/rust_workflow.rs) | Rust | 0 | 46 | 7 | 53 |
| [src/tutorials/solar_quick_start.rs](/src/tutorials/solar_quick_start.rs) | Rust | 0 | 178 | 3 | 181 |
| [src/tutorials/traits.rs](/src/tutorials/traits.rs) | Rust | 0 | 27 | 0 | 27 |
| [src/tutorials/work_with_clones_and_copies.rs](/src/tutorials/work_with_clones_and_copies.rs) | Rust | 0 | 58 | 0 | 58 |
| [src/tutorials/work_with_references.rs](/src/tutorials/work_with_references.rs) | Rust | 0 | 37 | 2 | 39 |
| [src/utilities/binary_search.rs](/src/utilities/binary_search.rs) | Rust | 82 | 161 | 23 | 266 |
| [src/utilities/combinatorics.rs](/src/utilities/combinatorics.rs) | Rust | 61 | 41 | 29 | 131 |
| [src/utilities/distances.rs](/src/utilities/distances.rs) | Rust | 23 | 2 | 17 | 42 |
| [src/utilities/functions/compose.rs](/src/utilities/functions/compose.rs) | Rust | 55 | 29 | 41 | 125 |
| [src/utilities/functions/evaluate.rs](/src/utilities/functions/evaluate.rs) | Rust | 313 | 278 | 184 | 775 |
| [src/utilities/functions/misc_functions.rs](/src/utilities/functions/misc_functions.rs) | Rust | 13 | 14 | 9 | 36 |
| [src/utilities/functions/mod.rs](/src/utilities/functions/mod.rs) | Rust | 3 | 7 | 1 | 11 |
| [src/utilities/heaps/heap.rs](/src/utilities/heaps/heap.rs) | Rust | 174 | 170 | 68 | 412 |
| [src/utilities/heaps/mod.rs](/src/utilities/heaps/mod.rs) | Rust | 1 | 2 | 3 | 6 |
| [src/utilities/indexing_and_bijection.rs](/src/utilities/indexing_and_bijection.rs) | Rust | 102 | 75 | 61 | 238 |
| [src/utilities/iterators/general.rs](/src/utilities/iterators/general.rs) | Rust | 502 | 321 | 204 | 1,027 |
| [src/utilities/iterators/is_sorted.rs](/src/utilities/iterators/is_sorted.rs) | Rust | 30 | 34 | 18 | 82 |
| [src/utilities/iterators/merge/heap_of_iterators.rs](/src/utilities/iterators/merge/heap_of_iterators.rs) | Rust | 284 | 286 | 111 | 681 |
| [src/utilities/iterators/merge/mod.rs](/src/utilities/iterators/merge/mod.rs) | Rust | 2 | 1 | 1 | 4 |
| [src/utilities/iterators/merge/two_iter_different_type.rs](/src/utilities/iterators/merge/two_iter_different_type.rs) | Rust | 75 | 27 | 32 | 134 |
| [src/utilities/iterators/mod.rs](/src/utilities/iterators/mod.rs) | Rust | 3 | 1 | 2 | 6 |
| [src/utilities/mod.rs](/src/utilities/mod.rs) | Rust | 12 | 5 | 1 | 18 |
| [src/utilities/order.rs](/src/utilities/order.rs) | Rust | 272 | 197 | 134 | 603 |
| [src/utilities/random.rs](/src/utilities/random.rs) | Rust | 51 | 10 | 18 | 79 |
| [src/utilities/sequences_and_ordinals.rs](/src/utilities/sequences_and_ordinals.rs) | Rust | 258 | 246 | 123 | 627 |
| [src/utilities/sets.rs](/src/utilities/sets.rs) | Rust | 35 | 20 | 13 | 68 |
| [src/utilities/statistics.rs](/src/utilities/statistics.rs) | Rust | 13 | 6 | 4 | 23 |
| [src/vectors/entries.rs](/src/vectors/entries.rs) | Rust | 167 | 137 | 114 | 418 |
| [src/vectors/implementors/csv.rs](/src/vectors/implementors/csv.rs) | Rust | 11 | 1 | 8 | 20 |
| [src/vectors/implementors/mod.rs](/src/vectors/implementors/mod.rs) | Rust | 1 | 0 | 0 | 1 |
| [src/vectors/linear_combinations.rs](/src/vectors/linear_combinations.rs) | Rust | 164 | 43 | 38 | 245 |
| [src/vectors/mod.rs](/src/vectors/mod.rs) | Rust | 3 | 43 | 5 | 51 |
| [src/vectors/operations.rs](/src/vectors/operations.rs) | Rust | 585 | 648 | 235 | 1,468 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)