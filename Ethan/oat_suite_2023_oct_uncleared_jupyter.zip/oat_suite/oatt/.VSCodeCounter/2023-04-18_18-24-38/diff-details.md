# Diff Details

Date : 2023-04-18 18:24:38

Directory /Users/roek189/Library/CloudStorage/OneDrive-PNNL/Desktop/a/r/c/l/multi/oat/oat_suite/solar

Total : 18 files,  357 codes, 287 comments, 125 blanks, all 769 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [src/chains/factored.rs](/src/chains/factored.rs) | Rust | 58 | 37 | 17 | 112 |
| [src/chains/jordan.rs](/src/chains/jordan.rs) | Rust | 226 | 60 | 43 | 329 |
| [src/chains/jordan_basis.rs](/src/chains/jordan_basis.rs) | Rust | -226 | -60 | -43 | -329 |
| [src/developer/job_list.rs](/src/developer/job_list.rs) | Rust | 0 | 12 | 0 | 12 |
| [src/matrices/developer_notes.rs](/src/matrices/developer_notes.rs) | Rust | 0 | 52 | 1 | 53 |
| [src/matrices/operations/umatch/row_major.rs](/src/matrices/operations/umatch/row_major.rs) | Rust | -24 | 25 | 0 | 1 |
| [src/matrices/oracles.rs](/src/matrices/oracles.rs) | Rust | -203 | -351 | -182 | -736 |
| [src/matrices/query.rs](/src/matrices/query.rs) | Rust | 470 | 417 | 271 | 1,158 |
| [src/matrices/types/dense.rs](/src/matrices/types/dense.rs) | Rust | 0 | 0 | 1 | 1 |
| [src/matrices/types/oracle_ref.rs](/src/matrices/types/oracle_ref.rs) | Rust | 6 | 1 | 0 | 7 |
| [src/utilities/binary_search.rs](/src/utilities/binary_search.rs) | Rust | -8 | 0 | 1 | -7 |
| [src/utilities/distances.rs](/src/utilities/distances.rs) | Rust | -3 | -1 | 0 | -4 |
| [src/utilities/indexing_and_bijection.rs](/src/utilities/indexing_and_bijection.rs) | Rust | 7 | 7 | 1 | 15 |
| [src/utilities/iterators/general.rs](/src/utilities/iterators/general.rs) | Rust | 10 | 11 | 2 | 23 |
| [src/utilities/iterators/merge/two_iter_different_type.rs](/src/utilities/iterators/merge/two_iter_different_type.rs) | Rust | 3 | 0 | -1 | 2 |
| [src/utilities/order.rs](/src/utilities/order.rs) | Rust | 272 | 197 | 134 | 603 |
| [src/utilities/partial_order.rs](/src/utilities/partial_order.rs) | Rust | -229 | -126 | -121 | -476 |
| [src/utilities/sequences_and_ordinals.rs](/src/utilities/sequences_and_ordinals.rs) | Rust | -2 | 6 | 1 | 5 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details