# Summary

Date : 2023-04-18 18:24:38

Directory /Users/roek189/Library/CloudStorage/OneDrive-PNNL/Desktop/a/r/c/l/multi/oat/oat_suite/solar

Total : 96 files,  14481 codes, 10767 comments, 5971 blanks, all 31219 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Rust | 91 | 14,406 | 10,767 | 5,928 | 31,101 |
| Markdown | 5 | 75 | 0 | 43 | 118 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 96 | 14,481 | 10,767 | 5,971 | 31,219 |
| . (Files) | 4 | 72 | 0 | 40 | 112 |
| src | 92 | 14,409 | 10,767 | 5,931 | 31,107 |
| src (Files) | 2 | 10 | 341 | 9 | 360 |
| src/bin | 1 | 3 | 0 | 4 | 7 |
| src/chains | 3 | 559 | 199 | 112 | 870 |
| src/developer | 5 | 4 | 248 | 3 | 255 |
| src/matrices | 41 | 10,110 | 6,169 | 4,107 | 20,386 |
| src/matrices (Files) | 7 | 854 | 683 | 357 | 1,894 |
| src/matrices/help | 5 | 4 | 413 | 4 | 421 |
| src/matrices/operations | 15 | 7,621 | 3,657 | 2,728 | 14,006 |
| src/matrices/operations (Files) | 7 | 1,655 | 904 | 632 | 3,191 |
| src/matrices/operations/solve | 3 | 1,178 | 500 | 433 | 2,111 |
| src/matrices/operations/umatch | 5 | 4,788 | 2,253 | 1,663 | 8,704 |
| src/matrices/types | 14 | 1,631 | 1,416 | 1,018 | 4,065 |
| src/rings | 5 | 422 | 448 | 163 | 1,033 |
| src/rings (Files) | 2 | 57 | 131 | 51 | 239 |
| src/rings/operator_structs | 3 | 365 | 317 | 112 | 794 |
| src/tutorials | 7 | 6 | 557 | 36 | 599 |
| src/utilities | 22 | 2,364 | 1,933 | 1,097 | 5,394 |
| src/utilities (Files) | 10 | 909 | 763 | 423 | 2,095 |
| src/utilities/functions | 4 | 384 | 328 | 235 | 947 |
| src/utilities/heaps | 2 | 175 | 172 | 71 | 418 |
| src/utilities/iterators | 6 | 896 | 670 | 368 | 1,934 |
| src/utilities/iterators (Files) | 3 | 535 | 356 | 224 | 1,115 |
| src/utilities/iterators/merge | 3 | 361 | 314 | 144 | 819 |
| src/vectors | 6 | 931 | 872 | 400 | 2,203 |
| src/vectors (Files) | 4 | 919 | 871 | 392 | 2,182 |
| src/vectors/implementors | 2 | 12 | 1 | 8 | 21 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)