# Diff Summary

Date : 2023-04-18 18:24:38

Directory /Users/roek189/Library/CloudStorage/OneDrive-PNNL/Desktop/a/r/c/l/multi/oat/oat_suite/solar

Total : 18 files,  357 codes, 287 comments, 125 blanks, all 769 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Rust | 18 | 357 | 287 | 125 | 769 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 18 | 357 | 287 | 125 | 769 |
| src | 18 | 357 | 287 | 125 | 769 |
| src/chains | 3 | 58 | 37 | 17 | 112 |
| src/developer | 1 | 0 | 12 | 0 | 12 |
| src/matrices | 6 | 249 | 144 | 91 | 484 |
| src/matrices (Files) | 3 | 267 | 118 | 90 | 475 |
| src/matrices/operations | 1 | -24 | 25 | 0 | 1 |
| src/matrices/operations/umatch | 1 | -24 | 25 | 0 | 1 |
| src/matrices/types | 2 | 6 | 1 | 1 | 8 |
| src/utilities | 8 | 50 | 94 | 17 | 161 |
| src/utilities (Files) | 6 | 37 | 83 | 16 | 136 |
| src/utilities/iterators | 2 | 13 | 11 | 1 | 25 |
| src/utilities/iterators (Files) | 1 | 10 | 11 | 2 | 23 |
| src/utilities/iterators/merge | 1 | 3 | 0 | -1 | 2 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)