//! Additional tools for work with simplices

pub mod permutation;