//! Data structures representing simplices


pub mod filtered;
pub mod unfiltered;
pub mod vector;