//! Compressed sparse vectors.




pub CompressedSparseVector< Index, Coeff >
{
    index: Vec<Index>,
    coeff: Vec<Coeff>
}


impl< Index, Coeff >
    CompressedSparseVector
    < Index, Coeff >
{
    fn iter( &self ) -> 
}

