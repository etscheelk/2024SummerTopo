



pub struct DenseMatrix< T >{
    vec:        Vec< T >,
    num_rows:   usize,
    num_cols:   usize,
}