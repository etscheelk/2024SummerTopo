//! Chain complexes.

pub mod factored;
pub mod jordan;
pub mod barcode;