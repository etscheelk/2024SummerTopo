//! For beginners through advanced users

pub mod rust;
pub mod oat_quick_start;
// pub mod homology_with_umatch;
pub mod homology;
pub mod persistent_homology;