//! Heaps; especially heaps of iterators, which can be used to merge multiple sorted iterators into a combined sorted interator
//! 


pub mod heap;
