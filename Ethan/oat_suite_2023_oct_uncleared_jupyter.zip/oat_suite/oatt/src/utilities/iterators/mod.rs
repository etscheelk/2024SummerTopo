//! General tools for working with iterators.

pub mod merge;
pub mod general;
pub mod is_sorted;
